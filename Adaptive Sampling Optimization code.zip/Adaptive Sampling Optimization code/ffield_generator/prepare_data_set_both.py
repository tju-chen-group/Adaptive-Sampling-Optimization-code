import os
import shutil
from collections import defaultdict

def prepare_data_set_error(initial_file_number):
    folder_name = 'individual_errors'
    data_folder_name = 'total_errors'
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)
    if not os.path.exists(data_folder_name):
        os.makedirs(data_folder_name)
        
    error = defaultdict(list)

    j = initial_file_number
    for subdir in os.listdir(os.getcwd()):
        if subdir.startswith('ffield'): 
            ffield_folder_name = subdir
            j += 1
            if os.path.exists(ffield_folder_name):
                os.chdir(ffield_folder_name)
                if (os.path.isfile("fort.99") == True):
                    file = open("fort.99", "r")
                    file_length = len(file.readlines())
                    file.seek(0)
                    file.readline()
                    file.readline()  # Skip the second line (for MAc, no need for ACI)
                    position = file.tell()
                    
                    try:
                        for i in range(0, file_length-2):
                            # Ffield value
                            file.seek(position+61)
                            ffield_value = file.read(11).strip()
                            if ffield_value:
                                try:
                                    error[i].append(float(ffield_value))
                                except ValueError:
                                    error[i].append(99999999)
                            else:
                                error[i].append(99999999)

                            # Quantum Chemical value
                            file.seek(position+73)
                            quantum_value = file.read(11).strip()
                            if quantum_value:
                                error[i].append(float(quantum_value))
                            else:
                                error[i].append(0)  # You may need to handle this case according to your logic

                            # Weight of the training set element
                            file.seek(position+85)
                            weight_value = file.read(11).strip()
                            if weight_value:
                                error[i].append(float(weight_value))
                            else:
                                error[i].append(0)  # You may need to handle this case according to your logic

                            # Position to the beginning of next line
                            position = position + 121
                            file.seek(position)
                            null = file.readline()
                            if (file.tell() - position == 121):
                                file.seek(position)
                            else:
                                position = file.tell()
                    finally:
                        file.close()
                
                    # Individual error output subroutine
                    number_of_training_element = len(error)
                    file2 = open("individual_error", "w+")
                    file2.seek(0)

                    try:    
                        for i in range(0, number_of_training_element):
                            # 确保error[i]至少有3个元素，并且weight_value不是0
                            if len(error[i]) >= 3 and error[i][2] != 0:
                                # 根据ffield_value, quantum_value和weight_value计算total_error
                                total_error = "{:.2f}".format(((error[i][1]-error[i][0])/error[i][2])**2)
                                file2.write(str(i).rjust(10) + str(error[i][0]).rjust(12) + str(error[i][1]).rjust(12) + str(error[i][2]).rjust(12) + str(total_error).rjust(40) + "\n")
                            # 如果weight_value是0，则该行数据不会被写入
                    finally:
                        file2.close()

                    shutil.copy('individual_error', '../' + folder_name + '/individual_error' + str(j))
                    
                    # Total error subroutine   
                    if (os.path.isfile("parameters") == True):
                        shutil.copy('parameters', '../' + data_folder_name + '/parameters' + str(j))
                    else:
                        print("Parameters file does not exist")
                        
                    os.chdir('..')
                else:
                    print("File does not exist.")

                    # Total error subroutine   
                    if (os.path.isfile("parameters") == True):
                        shutil.copy('parameters', '../' + data_folder_name + '/parameters' + str(j))
                    else:
                        print("Parameters file does not exist")

                    os.chdir('..')

                error.clear()
            if not os.path.exists(ffield_folder_name):
                print("ffield-" + str(j) + " does not exist.")
