"""Read the params file and gets the ffield parameters as input"""

from pyDOE import *
from collections import defaultdict
from sobol_seq import i4_sobol_generate

def parameter_generator(parameters, cycle):
    try:
        length = len(parameters)
        parameters_a = defaultdict(list)

        hc = i4_sobol_generate(length, cycle)
        
        for j in range(cycle):
            for i in range(length):
                parameters_a[j].append((float(parameters[i][5])-float(parameters[i][4]))*hc[j][i]+float(parameters[i][4]))
        
    except IOError:
        pass
        
    return parameters_a
